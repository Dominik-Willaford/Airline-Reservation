﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.ModelBinding;
using System.Drawing;

namespace Airline_Reservation
{
    public partial class Flights : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


             SqlConnection conn = new SqlConnection();
             conn.ConnectionString = " Data Source=LADITSNDWILLAFO\\SQLEXPRESS1;Initial Catalog=Airline Reservation;Persist Security Info=True;User ID=user;Password=password";
             conn.Open();
             SqlCommand cmd = new SqlCommand("SELECT Flight_Schedules.FlightDate, Flight_Schedules.Departure, Flight_Schedules.Arrival, Route.Airport, Route.Destination, AirFare.Fare FROM Flight_Schedules INNER JOIN AirFare ON Flight_Schedules.NetFare = AirFare.AfID INNER JOIN Route ON AirFare.Route = Route.RtID", conn);
             SqlDataReader rdr = cmd.ExecuteReader();
             //GV_Grid.DataSource = rdr;
             GV_Grid.DataBind();
             conn.Close();
        }

      


         protected void Button1_Click(object sender, EventArgs e)
         {
             Calendar1.Visible = true;
         }

         protected void Calendar1_SelectionChanged(object sender, EventArgs e)
         {
             TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
             Calendar1.Visible = false;
         }

        protected void GV_Grid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if(e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(GV_Grid, "Select$" + e.Row.RowIndex);
                e.Row.ToolTip = "Click to select flight.";
            }
        }

        protected void GV_Grid_SelectedIndexChanged(object sender, EventArgs e)
        {
            GV_Grid.SelectedRow.RowIndex.ToString();
            foreach(GridViewRow row in GV_Grid.Rows)
            {
                if(row.RowIndex == GV_Grid.SelectedIndex)
                {
                    
                   //row.BackColor = ColorTranslator.FromHtml("#AlDCF2");
                   // row.ToolTip = string.Empty;
                    string Airport;
                    Airport = row.Cells[1].Text;
                    string Destination;
                    Destination = row.Cells[2].Text;
                    string FlightDate;
                    FlightDate = row.Cells[3].Text;
                    string Departure;
                    Departure = row.Cells[4].Text;
                    string Arrival;
                    Arrival = row.Cells[5].Text;
                    string Fare;
                    Fare = row.Cells[6].Text;

                    
                    Label2.Text = "Your flight will depart from: " +Airport;
                    Label3.Text = "Your flight will arrive at: " + Destination;
                    Label4.Text = "Your flight will be on: " + FlightDate;
                    Label5.Text = "Your flight's departure will be: " + Departure;
                    Label6.Text = "Your flight's arrival will be: " + Arrival;

                }
                else
                {
                    row.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                    row.ToolTip = "Click to select flight";
                }
            }
            Label2.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Label5.Visible = true;
            Label6.Visible = true;
        }
    }
}